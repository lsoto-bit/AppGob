# Secciones internas — ejemplos (v6.1 / Segundo-Test)

## Documentos
- `01-documentos-lista.jpg` — listado
- `01b-documento-cedula-visualizacion.jpg` — vista de cédula (ejemplo)

## Notificaciones
- `02-notificaciones-lista.jpg` — listado
- `02b-notificacion-gas-detalle.jpg` — detalle Cupón de Gas Licuado

## Alertas
- `03-alertas-lista.jpg` — listado
- `03b-alerta-gas-abre-notificacion.jpg` — alerta del gas → abre notificación

## ClaveÚnica
- `04-claveunica-actividad.jpg` — historial de actividad
- `04b-claveunica-saliendo.jpg` — splash al salir
- `04c-claveunica-validar-identidad.jpg` — validación en browser
- `04d-claveunica-push.jpg` — push de código
- `04e-claveunica-volviendo.jpg` — splash de retorno
- `04f-claveunica-modal-codigo.jpg` — modal con código

## Deudas
- `05-deudas-lista.jpg` — listado
- `05b-deuda-detalle.jpg` — detalle (permiso de circulación)
- `05c-deuda-metodo-pago.jpg` — método de pago
- `05d-deuda-confirmacion.jpg` — confirmación

## Perfil / Lugares (extra)
- `06-perfil.jpg` / `06b-perfil-rsh-interno.jpg`
- `07-lugares-lista.jpg` / `07b-lugar-oficina-detalle.jpg`
